/* Host-only regression tests of production sources, not a timing simulator.
 * Model assumptions: reserved feature bits read as 0x28 (old PDF) or 0x00
 * (new PDF). Writes require a full 24-clock frame and return the register echo.
 * Critical sections are no-ops in this single-thread model; RTOS scheduling,
 * stack watermark and electrical behavior require target-board validation.
 */
#include "spi.h"
#include "task.h"
#include "ads8688.h"
#include "laser_task.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

SPI_HandleTypeDef hspi2;
static uint8_t regs[64], reserved, selected, last_command;
static uint16_t raw[8];
static int cs_high = 1, fail_read, corrupt_read, fail_channel = -1, bad_tag_channel = -1;
static unsigned writes, conversions;
static uint32_t mock_tick;
static int corrupt_echo, disconnected, corrupt_pd_echo;
static unsigned pd_writes;
void HAL_GPIO_WritePin(void *port, uint16_t pin, int state)
{ (void)port; (void)pin; cs_high = state; }
HAL_StatusTypeDef HAL_SPI_Abort(SPI_HandleTypeDef *spi) { (void)spi; return HAL_OK; }
void HAL_Delay(uint32_t ms) { (void)ms; }
TickType_t xTaskGetTickCount(void) { return mock_tick; }
void vTaskDelayUntil(TickType_t *tick, TickType_t period) { *tick += period; }

static void device_reset(void)
{
    memset(regs, 0, sizeof(regs));
    regs[1] = 0xFF; regs[3] = reserved; selected = 0; last_command = 0;
}
static void scenario(uint8_t feature_reserved)
{
    reserved = feature_reserved; device_reset();
    writes = conversions = 0; fail_read = corrupt_read = 0; fail_channel = bad_tag_channel = -1;
    mock_tick = 0; corrupt_echo = disconnected = 0;
    corrupt_pd_echo = 0; pd_writes = 0;
    g_laser_reinit_count = 0;
    g_ads_calibration.enabled = 0;
    g_ads_sample_error_count = 0;
    g_ads_init_error_count = 0;
    memset((void *)&g_ads_first_fault, 0, sizeof(g_ads_first_fault));
    memset((void *)&g_ads_last_fault, 0, sizeof(g_ads_last_fault));
    for (unsigned i = 0; i < 8; ++i) raw[i] = (uint16_t)(30000 + i * 1000);
}
HAL_StatusTypeDef HAL_SPI_TransmitReceive(SPI_HandleTypeDef *spi, const uint8_t *tx,
                                        uint8_t *rx, uint16_t size, uint32_t timeout)
{
    (void)spi; (void)timeout;
    assert(!cs_high);
    memset(rx, 0, size);
    if (disconnected) { memset(rx, 0xFF, size); return HAL_OK; }
    uint16_t cmd = (uint16_t)((tx[0] << 8) | tx[1]);
    if (cmd == 0x8500) { device_reset(); return HAL_OK; }
    if (size == 3 && (tx[0] & 1)) {
        unsigned address = tx[0] >> 1;
        assert(tx[0] & 1);
        regs[address] = address == 3 ? ((tx[1] & 0xC7) | reserved) : tx[1];
        rx[2] = regs[address];
        if (address == 2) {
            ++pd_writes;
            if (corrupt_pd_echo) { rx[2] ^= 2U; corrupt_pd_echo = 0; }
        }
        if (corrupt_echo) { rx[2] ^= 1U; corrupt_echo = 0; }
        ++writes;
        return HAL_OK;
    }
    if (size == 3) {
        unsigned address = tx[0] >> 1;
        if (fail_read && address == 5) { fail_read = 0; return HAL_TIMEOUT; }
        if (corrupt_read && address == 6) { corrupt_read = 0; rx[2] = 0; return HAL_OK; }
        rx[2] = address == 0x3F ? last_command : regs[address];
        return HAL_OK;
    }
    assert(size == 5);
    ++conversions;
    if (cmd == 0 && (int)selected == fail_channel) {
        fail_channel = -1; return HAL_TIMEOUT;
    }
    rx[2] = (uint8_t)(raw[selected] >> 8); rx[3] = (uint8_t)raw[selected];
    if ((regs[3] & 7) == 1) {
        uint8_t tag = (int)selected == bad_tag_channel ? (selected ^ 7) : selected;
        rx[4] = (uint8_t)(tag << 4);
    }
    if ((cmd & 0xE000) == 0xC000) {
        selected = (uint8_t)((cmd >> 10) & 7); last_command = tx[0];
    }
    return HAL_OK;
}
static void scan(void) { for (int i = 0; i < 10; ++i) app_task_10ms(); }
int main(void)
{
    scenario(0x28); app_init();
    assert(g_ads_init_ok == 1 && g_ads_command_readback == 0xDC);
    unsigned before = conversions;
    for (int i = 0; i < 9; ++i) app_task_10ms();
    assert(g_laser_sample_count == 0);
    app_task_10ms();
    assert(g_laser_sample_count == 1 && conversions - before == 16);
    assert(g_ads_channel_valid_mask == 0xFF && isfinite(g_distance_mm));
    for (int i = 0; i < 8; ++i) assert(g_ads_channel_raw[i] == raw[i]);
    puts("PASS: legacy register model, cadence, 8-channel mapping, MAN+NOOP frames");

    scenario(0); app_init(); scan();
    assert(g_ads_feature_readback == 1 && g_ads_init_ok == 1);
    assert(g_ads_channel_valid_mask == 0xFF && g_ads_sample_error_count == 0);
    assert(isfinite(g_distance_mm));
    puts("PASS: newer feature readback 0x01 accepted; functional bits validated");

    scenario(0x28); app_init();
    g_ads_calibration.raw_low = 1000; g_ads_calibration.raw_high = 61000;
    g_ads_calibration.enabled = 1; scan();
    assert(conversions - before != 0); /* service below is the only extra read */
    before = conversions;
    scan();
    assert(conversions - before == 16);
    float service = ADS_GetDistance_mm();
    assert(fabsf(service - 5025.0f) < 0.01f);
    assert(fabsf(g_distance_mm - service) < 0.01f);
    printf("PASS: calibration service=%.3f mm, published distance=%.3f mm\n",
           (double)service, (double)g_distance_mm);

    scenario(0x28); fail_read = 1; app_init();
    assert(g_ads_init_ok == 0);
    assert(g_ads_first_fault.hal_status == HAL_TIMEOUT);
    uint32_t first_sequence = g_ads_first_fault.sequence;
    before = writes;
    for (int i = 0; i < 99; ++i) app_task_10ms();
    assert(writes == before && g_laser_reinit_count == 0);
    for (int i = 0; i < 11; ++i) app_task_10ms();
    assert(g_ads_channel_valid_mask == 0xFF && g_ads_init_ok == 1);
    assert(isfinite(g_distance_mm) && writes > before);
    assert(g_ads_init_error_count == 1 && g_ads_first_fault.sequence == first_sequence);
    puts("PASS: startup read timeout recovers through bounded reinitialization");

    scenario(0x28); app_init(); scan();
    corrupt_read = 1;
    before = conversions;
    scan();
    assert(g_ads_init_ok == 0 && isnan(g_distance_mm) && conversions == before);
    for (int i = 0; i < 110; ++i) app_task_10ms();
    assert(g_ads_init_ok == 1 && g_ads_channel_valid_mask == 0xFF && isfinite(g_distance_mm));
    puts("PASS: runtime configuration corruption is detected and repaired");

    scenario(0x28); app_init(); fail_channel = 1; scan();
    assert(!(g_ads_channel_valid_mask & 2) && isnan(g_distance_mm));
    assert(g_ads_sample_error_count == 1);
    scan(); assert(g_ads_channel_valid_mask == 0xFF && isfinite(g_distance_mm));
    puts("PASS: AIN1 transient transfer failure invalidates distance and next scan recovers");

    scenario(0x28); app_init(); bad_tag_channel = 1; scan();
    assert(!(g_ads_channel_valid_mask & 2) && isnan(g_distance_mm));
    assert(g_ads_sample_error_count == 1);
    puts("PASS: incorrect channel tag invalidates AIN1");

    /* Three consecutive tag failures force reconfiguration, retaining counters. */
    scan(); scan();
    assert(g_ads_init_ok == 0 && g_ads_sample_error_count == 3);
    bad_tag_channel = -1;
    for (int i = 0; i < 110; ++i) app_task_10ms();
    assert(g_ads_init_ok && isfinite(g_distance_mm) && g_ads_sample_error_count == 3);
    puts("PASS: persistent conversion errors trigger recovery without clearing counters");

    scenario(0); corrupt_echo = 1; app_init();
    assert(!g_ads_init_ok && g_ads_first_fault.code == ADS_FAULT_REGISTER);
    assert(g_ads_range_write_echo == 4 && g_ads_first_fault.actual == 4);
    assert(g_ads_first_fault.expected == 5);
    puts("PASS: real write-echo mismatch rejects initialization and preserves diagnostics");

    scenario(0); disconnected = 1; app_init();
    for (int i = 0; i < 200; ++i) app_task_10ms();
    assert(!g_ads_init_ok && isnan(g_distance_mm));
    assert(g_laser_reinit_count == 2 && g_ads_init_error_count == 3);
    disconnected = 0;
    for (int i = 0; i < 110; ++i) app_task_10ms();
    assert(g_ads_init_ok && isfinite(g_distance_mm));
    puts("PASS: disconnected bus retries at backoff interval, then recovers");

    scenario(0); app_init(); scan(); device_reset();
    scan(); assert(!g_ads_init_ok && isnan(g_distance_mm));
    for (int i = 0; i < 110; ++i) app_task_10ms();
    assert(g_ads_init_ok && g_ads_feature_readback == 1 && isfinite(g_distance_mm));
    puts("PASS: ADC runtime reset is detected and range/format restored");

    scenario(0); app_init();
    g_ads_calibration = (ADS_Calibration){61000, 1000, 1}; scan();
    assert(fabsf(g_distance_mm - 5025.0f) < 0.01f);
    assert(fabsf(ADS_RawToDistance_mm(61000) - 50.0f) < 0.01f);
    assert(fabsf(ADS_RawToDistance_mm(1000) - 10000.0f) < 0.01f);
    g_ads_calibration.raw_high = 61000; scan();
    LaserSample sample;
    Laser_GetSample(&sample);
    assert(isnan(g_distance_mm) && (sample.status & LASER_SAMPLE_CALIBRATION_ERROR));
    puts("PASS: reverse calibration endpoints and invalid equal endpoints");

    scenario(0); app_init(); mock_tick = UINT32_MAX - 50U; scan();
    mock_tick += 100U; Laser_GetSample(&sample);
    assert(sample.valid_mask == 0xFF && !(sample.status & LASER_SAMPLE_STALE));
    assert(sample.sequence == g_laser_sample_count && sample.raw[1] == raw[1]);
    mock_tick += 151U; Laser_GetSample(&sample);
    assert(isnan(sample.distance_mm) && sample.valid_mask == 0 && (sample.status & LASER_SAMPLE_STALE));
    raw[1] = 65535; scan(); Laser_GetSample(&sample);
    assert(sample.status & LASER_SAMPLE_ADC_RAIL);
    puts("PASS: coherent snapshot, stale timeout across tick wrap, rail warning");
    scenario(0); app_init(); scan();
    assert(pd_writes == 1 && g_ads_ch_pd_initial == 0 && g_ads_ch_pd_readback == 0);
    /* Valid channel tags alone cannot detect an analog front end powered down. */
    regs[2] = 2;
    before = conversions;
    scan();
    assert(!g_ads_init_ok && isnan(g_distance_mm) && conversions == before);
    assert(g_ads_ch_pd_readback == 2 && g_ads_last_fault.code == ADS_FAULT_REGISTER);
    assert(g_ads_last_fault.command == 0x0400 && g_ads_last_fault.actual == 2);
    assert(g_ads_last_fault.expected == 0);
    for (int i = 0; i < 110; ++i) app_task_10ms();
    assert(g_ads_init_ok && pd_writes == 2 && g_ads_ch_pd_readback == 0);
    assert(isfinite(g_distance_mm));
    puts("PASS: channel power-down detected before conversion; reinitialization restores power");

    scenario(0); corrupt_pd_echo = 1; app_init();
    assert(!g_ads_init_ok && g_ads_first_fault.code == ADS_FAULT_REGISTER);
    assert(g_ads_first_fault.command == 0x0400 && g_ads_first_fault.actual == 2);
    assert(g_ads_first_fault.expected == 0);
    puts("PASS: channel power register write-echo mismatch rejects initialization");
    puts("15 scenarios verified against the fixed production sources.");
    return 0;
}
