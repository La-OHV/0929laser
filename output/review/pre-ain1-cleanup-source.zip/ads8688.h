#ifndef INC_0929LASER_ADS8688_H
#define INC_0929LASER_ADS8688_H

#include <stdint.h>

#define ADS_INPUT_CHANNEL 1U
#define ADS_CHANNEL_COUNT 8U
#define ADS_REFERENCE_VOLTAGE 4.096f
#define ADS_DISTANCE_LOW_MM 50.0f
#define ADS_DISTANCE_HIGH_MM 10000.0f

typedef enum {
    ADS_FAULT_NONE = 0,
    ADS_FAULT_TRANSFER,
    ADS_FAULT_REGISTER,
    ADS_FAULT_TAG,
    ADS_FAULT_NOT_READY,
    ADS_FAULT_CHANNEL
} ADS_FaultCode;

typedef struct {
    uint32_t sequence;
    ADS_FaultCode code;
    uint16_t command;
    uint16_t actual;
    uint16_t expected;
    uint8_t hal_status;
    uint8_t rx[5];
} ADS_Fault;

/* 驱动只由 laser_task 调用。其他任务读取 Laser_GetSample 快照。
 * 下面变量用于Watch，不提供多变量原子一致性。
 */
extern volatile uint16_t g_ads_range_readback;
extern volatile uint8_t g_ads_range_readback_all[ADS_CHANNEL_COUNT];
extern volatile uint8_t g_ads_spi_ok;
extern volatile uint16_t g_ads_last_rx[2];
/* 最近一次 SPI 帧的完整字节，便于逻辑分析仪/Watch 对照。 */
extern volatile uint8_t g_ads_last_frame_tx[5];
extern volatile uint8_t g_ads_last_frame_rx[5];
extern volatile uint8_t g_ads_channel_frame_rx[ADS_CHANNEL_COUNT][5];
extern volatile uint16_t g_ads_range_write_echo; /* 最近量程写入的实际第三字节回显 */
extern volatile uint8_t g_ads_command_readback;
extern volatile uint8_t g_ads_feature_readback; /* 功能位为01；完整值可能01或29 */
extern volatile uint8_t g_ads_ch_pd_initial; /* 最近初始化时，复位后/写入前的02h读回 */
extern volatile uint8_t g_ads_ch_pd_readback; /* 02h通道掉电状态，正常为00 */
extern volatile uint8_t g_ads_channel_tag[ADS_CHANNEL_COUNT];
extern volatile uint8_t g_ads_channel_valid_mask;
extern volatile uint32_t g_ads_sample_error_count; /* 累计，重新初始化不清零 */
extern volatile uint32_t g_ads_init_error_count;
extern volatile ADS_Fault g_ads_first_fault; /* 首次故障，后续传输和重试不会覆盖 */
extern volatile ADS_Fault g_ads_last_fault;

uint8_t ADS_Init(void);
uint8_t ADS_CheckConfiguration(void); /* 每轮采样前检查通道上电/量程/输出格式 */
uint16_t ADS_ReadChannelRaw(uint8_t channel);
uint16_t ADS_ReadRaw(void);
float ADS_ReadVoltage(void);

typedef struct {
    uint16_t raw_low;  /* ADS_DISTANCE_LOW_MM对应码值 */
    uint16_t raw_high; /* ADS_DISTANCE_HIGH_MM对应码值，可小于raw_low */
    uint8_t enabled;   /* 启用后端点相等返回NAN */
} ADS_Calibration;

/* 在采样任务停止时修改，或用临界区一次更新整个结构；调试器修改时暂停CPU。 */
extern volatile ADS_Calibration g_ads_calibration;
float ADS_RawToDistance_mm(uint16_t raw); /* 纯换算，不额外读SPI；默认0..10V线性映射 */
float ADS_GetDistance_mm(void);

#endif
