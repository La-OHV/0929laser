//
// Created by 23906 on 2026/9/29.
//

#ifndef INC_0929LASER_LASER_TASK_H
#define INC_0929LASER_LASER_TASK_H
#include <stdint.h>
#define LASER_SAMPLE_NOT_READY 0x01U
#define LASER_SAMPLE_IO_ERROR 0x02U
#define LASER_SAMPLE_CALIBRATION_ERROR 0x04U
#define LASER_SAMPLE_ADC_RAIL 0x08U
#define LASER_SAMPLE_STALE 0x10U

typedef struct {
    float distance_mm;
    uint16_t raw[8];
    uint8_t valid_mask;
    uint8_t status;
    uint32_t sequence;
    uint32_t tick; /* 采样开始时RTOS tick；当前1 tick=1 ms */
} LaserSample;

/* 任务上下文调用，整组复制；超过250ms未更新时返回STALE和NAN。 */
void Laser_GetSample(LaserSample *sample);
extern volatile uint32_t g_laser_reinit_count;
extern volatile uint32_t g_laser_overrun_count;
extern volatile uint32_t g_laser_max_execution_ticks;
extern volatile uint32_t g_laser_stack_free_bytes;
/* 单位 mm；尚未采集、初始化失败或通信失败时为 NAN。 */
extern volatile float g_distance_mm;
extern volatile uint32_t g_laser_task_count;
extern volatile uint32_t g_laser_sample_count;
extern volatile uint16_t g_ads_channel_raw[8];
extern volatile uint8_t g_ads_init_ok; /* ADC配置成功时为1；失败时后台按退避策略重试。 */

void app_init(void);
void app_task_10ms(void);        /* 每 10ms 调用，内部每 100ms 采集 */
void laser_task(void *argument);

#endif //INC_0929LASER_LASER_TASK_H
