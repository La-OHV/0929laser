//
// Created by 23906 on 2026/9/29.
//

#include "laser_task.h"
//
// Created by 23906 on 2026/9/24.
//

#include "../DRV+SEV/ads8688.h"
#include "FreeRTOS.h"
#include "task.h"
#include <math.h>
#include <stddef.h>

volatile float g_distance_mm = NAN;
volatile uint32_t g_laser_task_count = 0U;
volatile uint32_t g_laser_sample_count = 0U;
volatile uint16_t g_ads_channel_raw[8] = {0U};
volatile uint8_t g_ads_init_ok = 0U;
static uint8_t sample_count = 0U;//采样计数器 任务跑10ms周期 ads每100ms才读一次
static uint8_t init_retry_count = 0U;
static uint8_t failed_scans = 0U;
static LaserSample published = {.distance_mm = NAN, .status = LASER_SAMPLE_NOT_READY};
volatile uint32_t g_laser_reinit_count;
volatile uint32_t g_laser_overrun_count;
volatile uint32_t g_laser_max_execution_ticks;
volatile uint32_t g_laser_stack_free_bytes;

static void publish_sample(const LaserSample *sample)
{
    taskENTER_CRITICAL();
    published = *sample;
    g_distance_mm = sample->distance_mm;
    for (uint8_t ch = 0; ch < 8U; ++ch) g_ads_channel_raw[ch] = sample->raw[ch];
    taskEXIT_CRITICAL();
}

void Laser_GetSample(LaserSample *sample)
{
    if (sample == NULL) return;
    taskENTER_CRITICAL();
    *sample = published;
    taskEXIT_CRITICAL();
    if ((TickType_t)(xTaskGetTickCount() - sample->tick) > pdMS_TO_TICKS(250U)) {
        sample->status |= LASER_SAMPLE_STALE;
        sample->distance_mm = NAN;
        sample->valid_mask = 0U;
    }
}

static void publish_unavailable(void)
{
    LaserSample sample = {.distance_mm = NAN, .status = LASER_SAMPLE_NOT_READY,
                          .sequence = g_laser_sample_count, .tick = xTaskGetTickCount()};
    g_ads_channel_valid_mask = 0U;
    publish_sample(&sample);
}
//初始化
void app_init(void)
{
    sample_count = 0U;//计数器归零
    g_laser_task_count = 0U;
    g_laser_sample_count = 0U;
    for (uint8_t channel = 0U; channel < 8U; ++channel)
    {
        g_ads_channel_raw[channel] = 0U;
    }
    publish_unavailable();
    g_ads_init_ok = ADS_Init();
    init_retry_count = 0U;
    failed_scans = 0U;
}
//10ms被调用一次
void app_task_10ms(void)
{
    ++g_laser_task_count; //正常运行时约每秒增加100，判断任务是否持续执行
    if (++sample_count >= 10U)
    {
        sample_count = 0U;
        /* 启动阶段若 ADC 配置失败，每秒重试一次；成功后才发布测量值。 */
        if (!g_ads_init_ok)
        {
            if (++init_retry_count >= 10U)
            {
                init_retry_count = 0U;
                ++g_laser_reinit_count;
                g_ads_init_ok = ADS_Init();
                failed_scans = 0U;
            }
            publish_unavailable();
            return;
        }
        /* 每轮确认通道上电、量程和SDO格式，避免把异常配置下的读数发布为距离。
         * 寄存器帧结束后，每一路仍用完整MAN+NOOP重新选择和采样。
         */
        if (!ADS_CheckConfiguration())
        {
            g_ads_init_ok = 0U;
            init_retry_count = 0U;
            publish_unavailable();
            return;
        }
        LaserSample sample = {.distance_mm = NAN, .tick = xTaskGetTickCount()};
        g_ads_channel_valid_mask = 0U;
        for (uint8_t channel = 0U; channel < 8U; ++channel)
        {
            sample.raw[channel] = ADS_ReadChannelRaw(channel);
            if (!g_ads_spi_ok && g_ads_last_fault.code == ADS_FAULT_TRANSFER)
                break; /* 总线超时后停止本轮，避免8路各等待10ms */
        }
        sample.valid_mask = g_ads_channel_valid_mask;
        if (sample.valid_mask != 0xFFU) {
            sample.status |= LASER_SAMPLE_IO_ERROR;
            if (++failed_scans >= 3U) {
                g_ads_init_ok = 0U;
                init_retry_count = 0U;
                sample.status |= LASER_SAMPLE_NOT_READY;
                sample.valid_mask = 0U;
                g_ads_channel_valid_mask = 0U;
            }
        } else {
            failed_scans = 0U;
        }
        if (sample.valid_mask & (1U << ADS_INPUT_CHANNEL)) {
            sample.distance_mm = ADS_RawToDistance_mm(sample.raw[ADS_INPUT_CHANNEL]);
            if (!isfinite(sample.distance_mm)) sample.status |= LASER_SAMPLE_CALIBRATION_ERROR;
            if (sample.raw[ADS_INPUT_CHANNEL] == 0U || sample.raw[ADS_INPUT_CHANNEL] == 65535U)
                sample.status |= LASER_SAMPLE_ADC_RAIL;
        }
        ++g_laser_sample_count; //采样函数返回后增加，正常约每秒10次；不代表通信成功
        sample.sequence = g_laser_sample_count;
        publish_sample(&sample);
    }
}

void laser_task(void *argument)
{
    (void)argument;
    app_init();
    TickType_t last_wake = xTaskGetTickCount();//记录上一次唤醒的时刻

    for (;;)
    {
        vTaskDelayUntil(&last_wake, pdMS_TO_TICKS(10U));//10ms 函数执行的时间会被自动吸收
        TickType_t start = xTaskGetTickCount();
        app_task_10ms();
        TickType_t now = xTaskGetTickCount();
        TickType_t elapsed = now - start;
        if (elapsed > g_laser_max_execution_ticks) g_laser_max_execution_ticks = elapsed;
        g_laser_stack_free_bytes = uxTaskGetStackHighWaterMark(NULL) * sizeof(StackType_t);
        /* 超期不连续补跑旧周期。重建基准，保证重试退避不会被追赶执行压缩。 */
        if ((TickType_t)(now - last_wake) >= pdMS_TO_TICKS(10U)) {
            ++g_laser_overrun_count;
            last_wake = now;
        }
    }
}
