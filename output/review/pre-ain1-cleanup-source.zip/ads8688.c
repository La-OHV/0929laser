#include "ads8688.h"
#include <math.h>
#include "spi.h"

#define ADS_CMD_NOOP 0x0000U
#define ADS_CMD_RESET 0x8500U
#define ADS_CMD_MANUAL(ch) (0xC000U | ((uint16_t)(ch) << 10))
#define ADS_CHANNEL_PD_REG 0x02U
#define ADS_RANGE_REG_BASE 0x05U
#define ADS_RANGE_UNIPOLAR 0x05U
#define ADS_FEATURE_REG 0x03U
#define ADS_FEATURE_MASK 0xC7U
#define ADS_FEATURE_TAG 0x01U
#define ADS_SPI_TIMEOUT_MS 10U

volatile uint16_t g_ads_range_readback;
volatile uint8_t g_ads_range_readback_all[ADS_CHANNEL_COUNT];
volatile uint8_t g_ads_spi_ok;
volatile uint16_t g_ads_last_rx[2];
volatile uint8_t g_ads_last_frame_tx[5];
volatile uint8_t g_ads_last_frame_rx[5];
volatile uint8_t g_ads_channel_frame_rx[ADS_CHANNEL_COUNT][5];
volatile uint16_t g_ads_range_write_echo;
volatile uint8_t g_ads_command_readback;
volatile uint8_t g_ads_feature_readback;
volatile uint8_t g_ads_ch_pd_initial;
volatile uint8_t g_ads_ch_pd_readback;
volatile uint8_t g_ads_channel_tag[ADS_CHANNEL_COUNT];
volatile uint8_t g_ads_channel_valid_mask;
volatile uint32_t g_ads_sample_error_count;
volatile uint32_t g_ads_init_error_count;
volatile ADS_Fault g_ads_first_fault;
volatile ADS_Fault g_ads_last_fault;
volatile ADS_Calibration g_ads_calibration;
static uint8_t ads_ready;
static uint8_t ads_last_tag;
static uint8_t last_rx[5];
static uint32_t fault_sequence;

static void ADS_RecordFault(ADS_FaultCode code, uint16_t command,
                            uint16_t actual, uint16_t expected, uint8_t status)
{
    ADS_Fault fault = {0};
    fault.sequence = ++fault_sequence;
    fault.code = code;
    fault.command = command;
    fault.actual = actual;
    fault.expected = expected;
    fault.hal_status = status;
    for (uint8_t i = 0; i < 5U; ++i) fault.rx[i] = last_rx[i];
    g_ads_last_fault = fault;
    if (g_ads_first_fault.code == ADS_FAULT_NONE) g_ads_first_fault = fault;
    g_ads_spi_ok = 0U;
}

static uint8_t ADS_Transfer(const uint8_t *tx, uint8_t size)
{
    uint8_t rx[5] = {0};
    uint16_t command = ((uint16_t)tx[0] << 8) | tx[1];
    HAL_GPIO_WritePin(ADS_CS_GPIO_Port, ADS_CS_Pin, GPIO_PIN_RESET);
    HAL_StatusTypeDef status = HAL_SPI_TransmitReceive(&hspi2, tx, rx, size,
                                                       ADS_SPI_TIMEOUT_MS);
    HAL_GPIO_WritePin(ADS_CS_GPIO_Port, ADS_CS_Pin, GPIO_PIN_SET);
    for (uint8_t i = 0; i < 5U; ++i) {
        g_ads_last_frame_tx[i] = (i < size) ? tx[i] : 0U;
        last_rx[i] = rx[i];
        g_ads_last_frame_rx[i] = rx[i];
    }
    g_ads_last_rx[0] = ((uint16_t)rx[0] << 8) | rx[1];
    g_ads_last_rx[1] = ((uint16_t)rx[2] << 8) | rx[3];
    if (status != HAL_OK) {
        ADS_RecordFault(ADS_FAULT_TRANSFER, command, 0U, 0U, (uint8_t)status);
        return 0U;
    }
    return 1U;
}

static uint16_t ADS_XferConversion(uint16_t command)
{
    const uint8_t tx[5] = {(uint8_t)(command >> 8), (uint8_t)command, 0U, 0U, 0U};
    if (!ADS_Transfer(tx, 5U)) return 0U;
    ads_last_tag = last_rx[4] >> 4;
    return ((uint16_t)last_rx[2] << 8) | last_rx[3];
}

static uint8_t ADS_ReadRegister(uint8_t address)
{
    const uint8_t tx[3] = {(uint8_t)(address << 1), 0U, 0U};
    if (!ADS_Transfer(tx, 3U)) return 0U;
    return last_rx[2];
}

static uint8_t ADS_ExpectRegister(uint8_t address, uint8_t actual,
                                  uint8_t expected, uint8_t mask)
{
    if (!g_ads_spi_ok) return 0U;
    if ((actual & mask) != (expected & mask)) {
        ADS_RecordFault(ADS_FAULT_REGISTER, (uint16_t)address << 9,
                        actual, expected, HAL_OK);
        return 0U;
    }
    return 1U;
}

static uint8_t ADS_WriteRegister(uint8_t address, uint8_t value, uint8_t mask)
{
    const uint8_t tx[3] = {(uint8_t)((address << 1) | 1U), value, 0U};
    if (!ADS_Transfer(tx, 3U)) return 0U;
    if (address >= ADS_RANGE_REG_BASE && address < ADS_RANGE_REG_BASE + ADS_CHANNEL_COUNT)
        g_ads_range_write_echo = last_rx[2];
    return ADS_ExpectRegister(address, last_rx[2], value, mask);
}

uint8_t ADS_Init(void)
{
    ads_ready = 0U;
    g_ads_spi_ok = 1U;
    g_ads_channel_valid_mask = 0U;
    g_ads_range_readback = 0U;
    g_ads_range_write_echo = 0U;
    g_ads_feature_readback = 0U;
    g_ads_command_readback = 0U;
    g_ads_ch_pd_initial = 0xFFU;
    g_ads_ch_pd_readback = 0xFFU;
    for (uint8_t ch = 0; ch < ADS_CHANNEL_COUNT; ++ch) {
        g_ads_channel_tag[ch] = 0xFFU;
        g_ads_range_readback_all[ch] = 0xFFU;
    }
    HAL_GPIO_WritePin(ADS_CS_GPIO_Port, ADS_CS_Pin, GPIO_PIN_SET);
    /* 清理上一次超时后可能残留的接收数据、错误标志和 HAL busy 状态。 */
    HAL_StatusTypeDef abort_status = HAL_SPI_Abort(&hspi2);
    if (abort_status != HAL_OK) {
        ADS_RecordFault(ADS_FAULT_TRANSFER, 0U, 0U, 0U, (uint8_t)abort_status);
        goto failed;
    }
    HAL_Delay(25U);
    ADS_XferConversion(ADS_CMD_RESET);
    if (!g_ads_spi_ok) goto failed;
    HAL_Delay(25U);

    /* 旧/新资料保留位为101/000。保留读到的只读位，仅校验DEV和SDO。 */
    g_ads_feature_readback = ADS_ReadRegister(ADS_FEATURE_REG);
    if (!g_ads_spi_ok) goto failed;
    /* 复位后的 SDO/DEV 状态在不同资料版本和硬件批次上可能保留上一状态；
     * 此处只确认只读保留位合法，随后写入并严格校验最终功能配置。
     */
    uint8_t reserved = g_ads_feature_readback & 0x38U;
    if (reserved != 0U && reserved != 0x28U) {
        ADS_RecordFault(ADS_FAULT_REGISTER, ADS_FEATURE_REG << 9,
                        g_ads_feature_readback, 0U, HAL_OK);
        goto failed;
    }
    /* 保存本次初始化写入前的状态；复位默认应为00，不能把未显式写入视为根因。 */
    g_ads_ch_pd_initial = ADS_ReadRegister(ADS_CHANNEL_PD_REG);
    if (!g_ads_spi_ok) goto failed;
    for (uint8_t ch = 0; ch < ADS_CHANNEL_COUNT; ++ch) {
        uint8_t address = ADS_RANGE_REG_BASE + ch;
        if (!ADS_WriteRegister(address, ADS_RANGE_UNIPOLAR, 0xFFU)) goto failed;
        g_ads_range_readback = ADS_ReadRegister(address);
        g_ads_range_readback_all[ch] = (uint8_t)g_ads_range_readback;
        if (!ADS_ExpectRegister(address, (uint8_t)g_ads_range_readback,
                                ADS_RANGE_UNIPOLAR, 0xFFU)) goto failed;
    }
    /* CH_PD=1时，即使MAN选中该通道，转换数据也无效（手册8.5.2.3.1.2）。 */
    if (!ADS_WriteRegister(ADS_CHANNEL_PD_REG, 0U, 0xFFU)) goto failed;
    g_ads_ch_pd_readback = ADS_ReadRegister(ADS_CHANNEL_PD_REG);
    if (!ADS_ExpectRegister(ADS_CHANNEL_PD_REG, g_ads_ch_pd_readback, 0U, 0xFFU))
        goto failed;
    HAL_Delay(1U); /* 显式上电后的保守稳定间隔，仅初始化时等待。 */
    if (!ADS_WriteRegister(ADS_FEATURE_REG, reserved | ADS_FEATURE_TAG, ADS_FEATURE_MASK))
        goto failed;
    g_ads_feature_readback = ADS_ReadRegister(ADS_FEATURE_REG);
    if (!ADS_ExpectRegister(ADS_FEATURE_REG, g_ads_feature_readback,
                            ADS_FEATURE_TAG, ADS_FEATURE_MASK)) goto failed;
    ADS_XferConversion(ADS_CMD_MANUAL(7U));
    if (!g_ads_spi_ok) goto failed;
    g_ads_command_readback = ADS_ReadRegister(0x3FU);
    if (!ADS_ExpectRegister(0x3FU, g_ads_command_readback, 0xDCU, 0xFFU)) goto failed;
    ads_ready = 1U;
    return 1U;

failed:
    ++g_ads_init_error_count;
    return 0U;
}

uint8_t ADS_CheckConfiguration(void)
{
    if (!ads_ready) return 0U;
    g_ads_spi_ok = 1U;
    g_ads_ch_pd_readback = ADS_ReadRegister(ADS_CHANNEL_PD_REG);
    if (!ADS_ExpectRegister(ADS_CHANNEL_PD_REG, g_ads_ch_pd_readback, 0U, 0xFFU))
        goto failed;
    for (uint8_t ch = 0; ch < ADS_CHANNEL_COUNT; ++ch) {
        uint8_t address = ADS_RANGE_REG_BASE + ch;
        uint8_t value = ADS_ReadRegister(address);
        g_ads_range_readback_all[ch] = value;
        g_ads_range_readback = value;
        if (!ADS_ExpectRegister(address, value, ADS_RANGE_UNIPOLAR, 0xFFU)) goto failed;
    }
    g_ads_feature_readback = ADS_ReadRegister(ADS_FEATURE_REG);
    if (!ADS_ExpectRegister(ADS_FEATURE_REG, g_ads_feature_readback,
                            ADS_FEATURE_TAG, ADS_FEATURE_MASK)) goto failed;
    return 1U;
failed:
    ads_ready = 0U;
    g_ads_channel_valid_mask = 0U;
    return 0U;
}

uint16_t ADS_ReadChannelRaw(uint8_t channel)
{
    uint16_t raw = 0U;
    g_ads_spi_ok = 1U;
    if (channel >= ADS_CHANNEL_COUNT) {
        ADS_RecordFault(ADS_FAULT_CHANNEL, 0U, channel, 7U, HAL_OK);
        ++g_ads_sample_error_count;
        return 0U;
    }
    if (!ads_ready) {
        ADS_RecordFault(ADS_FAULT_NOT_READY, 0U, 0U, 1U, HAL_OK);
        goto failed;
    }
    ADS_XferConversion(ADS_CMD_MANUAL(channel));
    if (!g_ads_spi_ok) goto failed;
    raw = ADS_XferConversion(ADS_CMD_NOOP);
    if (!g_ads_spi_ok) goto failed;
    for (uint8_t i = 0; i < 5U; ++i) g_ads_channel_frame_rx[channel][i] = last_rx[i];
    g_ads_channel_tag[channel] = ads_last_tag;
    if (ads_last_tag != channel) {
        ADS_RecordFault(ADS_FAULT_TAG, ADS_CMD_NOOP, ads_last_tag, channel, HAL_OK);
        goto failed;
    }
    g_ads_channel_valid_mask |= (uint8_t)(1U << channel);
    return raw;
failed:
    g_ads_channel_valid_mask &= (uint8_t)~(1U << channel);
    ++g_ads_sample_error_count;
    return raw;
}

uint16_t ADS_ReadRaw(void) { return ADS_ReadChannelRaw(ADS_INPUT_CHANNEL); }

float ADS_ReadVoltage(void)
{
    uint16_t raw = ADS_ReadRaw();
    return g_ads_spi_ok ? (float)raw * (2.5f * ADS_REFERENCE_VOLTAGE) / 65536.0f : NAN;
}

float ADS_RawToDistance_mm(uint16_t raw)
{
    ADS_Calibration calibration = g_ads_calibration;
    if (calibration.enabled) {
        int32_t span = (int32_t)calibration.raw_high - (int32_t)calibration.raw_low;
        if (span == 0) return NAN;
        return ADS_DISTANCE_LOW_MM + ((float)raw - calibration.raw_low)
            * (ADS_DISTANCE_HIGH_MM - ADS_DISTANCE_LOW_MM) / (float)span;
    }
    return ADS_DISTANCE_LOW_MM + (float)raw * (2.5f * ADS_REFERENCE_VOLTAGE)
        * ((ADS_DISTANCE_HIGH_MM - ADS_DISTANCE_LOW_MM) / 10.0f) / 65536.0f;
}

float ADS_GetDistance_mm(void)
{
    uint16_t raw = ADS_ReadRaw();
    return g_ads_spi_ok ? ADS_RawToDistance_mm(raw) : NAN;
}
