//
// Created by 23906 on 2026/9/29.
//

#ifndef INC_0929LASER_ADS8688_H
#define INC_0929LASER_ADS8688_H


#include <stdint.h>

/* ==================== DRV：纯芯片操作 ==================== */
/* 初始化最后一路量程读回值应为0x05：VREF=4.096V时为0～10.24V。 */
extern volatile uint16_t g_ads_range_readback;
/* 当前操作状态（采样时含通道号校验）；不能证明模拟输入测量准确。 */
extern volatile uint8_t g_ads_spi_ok;
/* 最近一帧完整接收数据；初始化失败时保留量程读取帧，以十六进制观察。 */
extern volatile uint16_t g_ads_last_rx[2];
/* 最后一次写入的目标量程值，正常为0x05；实际读回值看 g_ads_range_readback。 */
extern volatile uint16_t g_ads_range_write_echo;
/* 初始化时通道7命令回读，正常为0xDC；正常采样期间不更新。 */
extern volatile uint8_t g_ads_command_readback;
extern volatile uint8_t g_ads_feature_readback; /* 应为0x29（十进制41）。 */
extern volatile uint8_t g_ads_channel_tag[8]; /* 最后一次传输成功的实际通道号；首次读取前为255。 */
extern volatile uint8_t g_ads_channel_valid_mask; /* 每路最近完成的读取是否通过通道号校验；全通过为255。 */
extern volatile uint32_t g_ads_sample_error_count; /* 采样传输失败或通道号校验失败累计次数，不含初始化。 */

uint8_t ADS_Init(void);          /* 1=初始化成功，0=失败 */
uint16_t ADS_ReadChannelRaw(uint8_t channel); /* 读取指定通道0～7 */
uint16_t ADS_ReadRaw(void);      /* AIN1 原始码值，配合 g_ads_spi_ok 判断有效性 */
float ADS_ReadVoltage(void);     /* AIN1，0～10.24V量程；VREF须为4.096V；通信失败返回NAN */

/* ==================== SVC：DT35 距离换算 ==================== */
typedef struct
{
    uint16_t raw_low;            /* 50mm 对应的实测码值 */
    uint16_t raw_high;           /* 10000mm 对应的实测码值 */
    uint8_t enabled;             /* 填好两点后置 1，要求 raw_high > raw_low */
} ADS_Calibration;

extern ADS_Calibration g_ads_calibration;
float ADS_GetDistance_mm(void);  /* 默认 50 + V * 995；通信失败返回 NAN */



#endif //INC_0929LASER_ADS8688_H
