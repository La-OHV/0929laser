//
// Created by 23906 on 2026/9/29.
//

#include "ads8688.h"
#include <math.h>
#include "spi.h"

#define ADS_CMD_NOOP             0x0000U //空指令
#define ADS_CMD_RESET            0x8500U //手册表6：复位程序寄存器
#define ADS_CMD_WRITE(reg, val)  (((uint16_t)(reg) << 9) | 0x0100U | (uint8_t)(val))
#define ADS_CMD_READ(reg)        ((uint16_t)(reg) << 9)
#define ADS_CMD_MANUAL(ch)       (0xC000U | ((uint16_t)(ch) << 10))
#define ADS_INPUT_CHANNEL        1U
#define ADS_RANGE_REG_BASE       0x05U //手册表9：通道0～7对应05h～0Ch
#define ADS_RANGE_0_10V24        0x05U //0～2.5*VREF；VREF=4.096V时为0～10.24V

volatile uint16_t g_ads_range_readback = 0U;
volatile uint8_t g_ads_spi_ok = 0U;
volatile uint16_t g_ads_last_rx[2] = {0U, 0U};
volatile uint16_t g_ads_range_write_echo = 0U;
volatile uint8_t g_ads_command_readback = 0U;
volatile uint8_t g_ads_feature_readback = 0U;
volatile uint8_t g_ads_channel_tag[8] = {0U};
volatile uint8_t g_ads_channel_valid_mask = 0U;
volatile uint32_t g_ads_sample_error_count = 0U;
static uint8_t ads_last_tag = 0xFFU;
ADS_Calibration g_ads_calibration = {0U, 0U, 0U};

/* ==================== DRV ==================== */
/* SDO=001：前16位命令，后16位转换结果，再读8位含实际通道号。 */
static uint16_t ADS_XferConversion(uint16_t command)
{
    uint8_t tx[5] = {
        (uint8_t)(command >> 8), (uint8_t)command, 0U, 0U, 0U
    };
    uint8_t rx[5] = {0U};
    HAL_StatusTypeDef status;

    HAL_GPIO_WritePin(ADS_CS_GPIO_Port, ADS_CS_Pin, GPIO_PIN_RESET);//拉低cs 片选引脚
    /* 共40个时钟，CS全程为低；最后一字节高4位为实际通道号。 */
    status = HAL_SPI_TransmitReceive(&hspi2, tx, rx, 5U, 10U);
    HAL_GPIO_WritePin(ADS_CS_GPIO_Port, ADS_CS_Pin, GPIO_PIN_SET);//拉高cs 结束本帧
    g_ads_last_rx[0] = ((uint16_t)rx[0] << 8) | rx[1];
    g_ads_last_rx[1] = ((uint16_t)rx[2] << 8) | rx[3];
    ads_last_tag = (uint8_t)(rx[4] >> 4);
    if (status != HAL_OK)
    {
        g_ads_spi_ok = 0U;
    }
    return g_ads_last_rx[1];
}

/* 按手册图89及厂家例程：24个时钟，第三字节为寄存器读回值。 */
static uint8_t ADS_ReadRegister(uint8_t address)
{
    /* 厂家例程的读时序为：8位地址/读命令 + 16位读时钟。 */
    uint8_t tx[3] = {(uint8_t)(address << 1), 0U, 0U};
    uint8_t rx[3] = {0U, 0U, 0U};
    HAL_StatusTypeDef status;

    HAL_GPIO_WritePin(ADS_CS_GPIO_Port, ADS_CS_Pin, GPIO_PIN_RESET);
    status = HAL_SPI_TransmitReceive(&hspi2, tx, rx, 3U, 10U);
    HAL_GPIO_WritePin(ADS_CS_GPIO_Port, ADS_CS_Pin, GPIO_PIN_SET);
    g_ads_last_rx[0] = ((uint16_t)rx[0] << 8) | rx[1];
    g_ads_last_rx[1] = rx[2];
    if (status != HAL_OK)
    {
        g_ads_spi_ok = 0U;
        return 0U;
    }
    return rx[2];
}

static uint8_t ADS_WriteRegister(uint8_t address, uint8_t value)
{
    uint8_t tx[2] = {(uint8_t)((address << 1) | 0x01U), value};
    uint8_t rx[2] = {0U, 0U};
    HAL_StatusTypeDef status;

    HAL_GPIO_WritePin(ADS_CS_GPIO_Port, ADS_CS_Pin, GPIO_PIN_RESET);
    status = HAL_SPI_TransmitReceive(&hspi2, tx, rx, 2U, 10U);
    HAL_GPIO_WritePin(ADS_CS_GPIO_Port, ADS_CS_Pin, GPIO_PIN_SET);
    g_ads_last_rx[0] = ((uint16_t)rx[0] << 8) | rx[1];
    g_ads_last_rx[1] = 0U;
    if (status != HAL_OK)
    {
        g_ads_spi_ok = 0U;
        return 0U;
    }
    return 1U;
}

uint8_t ADS_Init(void)
{
    uint8_t init_ok = 1U;

    g_ads_spi_ok = 1U;
    g_ads_range_readback = 0U;
    g_ads_range_write_echo = 0U;
    g_ads_channel_valid_mask = 0U;
    g_ads_sample_error_count = 0U;
    for (uint8_t channel = 0U; channel < 8U; ++channel)
    {
        g_ads_channel_tag[channel] = 0xFFU;
    }
    HAL_GPIO_WritePin(ADS_CS_GPIO_Port, ADS_CS_Pin, GPIO_PIN_SET);//cs先拉高
    HAL_Delay(25U); //等待模块电源及内部参考稳定后再发送命令
    ADS_XferConversion(ADS_CMD_RESET);//软件复位 发送一次reset命令
    HAL_Delay(25U);

    /* 诊断程序会读取全部8路，因此统一配置为0～10.24V并逐路读回验证。 */
    for (uint8_t channel = 0U; channel < 8U; ++channel)
    {
        uint8_t range_reg = ADS_RANGE_REG_BASE + channel;
        if (!ADS_WriteRegister(range_reg, ADS_RANGE_0_10V24))
        {
            init_ok = 0U;
        }
        g_ads_range_write_echo = ADS_RANGE_0_10V24;
        g_ads_range_readback = ADS_ReadRegister(range_reg);
        if (!g_ads_spi_ok || g_ads_range_readback != ADS_RANGE_0_10V24)
        {
            init_ok = 0U;
        }
    }
    /* 表12/13：保留位101，SDO=001，输出转换结果及实际通道号。 */
    if (!ADS_WriteRegister(0x03U, 0x29U))
    {
        init_ok = 0U;
    }
    g_ads_feature_readback = ADS_ReadRegister(0x03U);
    if (!g_ads_spi_ok || g_ads_feature_readback != 0x29U)
    {
        init_ok = 0U;
    }
    /* 命令回读只在初始化执行；正常采样时不插入寄存器读帧。 */
    ADS_XferConversion(ADS_CMD_MANUAL(7U));
    g_ads_command_readback = ADS_ReadRegister(0x3FU);
    if (!g_ads_spi_ok || g_ads_command_readback != 0xDCU)
    {
        init_ok = 0U;
    }
    g_ads_spi_ok = init_ok;
    return init_ok;
}
//读原始码值
uint16_t ADS_ReadChannelRaw(uint8_t channel)
{
    if (channel > 7U)
    {
        g_ads_spi_ok = 0U;
        return 0U;
    }
    /* 保留上一笔已完成的诊断结果，避免Watch读到采样中间的占位值。 */
    g_ads_spi_ok = 1U;//每次调用开始时把ok置1 任何一帧失败xfer里面都会置0
    ADS_XferConversion(ADS_CMD_MANUAL(channel)); /* 选择下一帧要采样的通道 */
    if (!g_ads_spi_ok)
    {
        g_ads_channel_valid_mask &= (uint8_t)~(1U << channel);
        ++g_ads_sample_error_count;
        return 0U;
    }
    /* MAN后紧接NOOP；40个SPI时钟已远大于器件的转换时间。 */
    uint16_t raw = ADS_XferConversion(ADS_CMD_NOOP);
    if (g_ads_spi_ok)
    {
        g_ads_channel_tag[channel] = ads_last_tag;
        if (g_ads_feature_readback == 0x29U && ads_last_tag == channel)
        {
            g_ads_channel_valid_mask |= (uint8_t)(1U << channel);
        }
        else
        {
            g_ads_spi_ok = 0U;
        }
    }
    if (!g_ads_spi_ok)
    {
        g_ads_channel_valid_mask &= (uint8_t)~(1U << channel);
        ++g_ads_sample_error_count;
    }
    return raw;
}

uint16_t ADS_ReadRaw(void)
{
    return ADS_ReadChannelRaw(ADS_INPUT_CHANNEL);
}
//读电压
float ADS_ReadVoltage(void)
{
    uint16_t raw = ADS_ReadRaw();
    return g_ads_spi_ok ? (float)raw * 10.24f / 65536.0f : NAN;
}

/* ==================== SVC ==================== */
//获取距离 校准与否
float ADS_GetDistance_mm(void)
{
    if (g_ads_calibration.enabled &&
        g_ads_calibration.raw_high > g_ads_calibration.raw_low)
    {
        uint16_t raw = ADS_ReadRaw();
        if (!g_ads_spi_ok)
        {
            return NAN;
        }
        return 50.0f + ((float)raw - (float)g_ads_calibration.raw_low)
             * 9950.0f / (float)(g_ads_calibration.raw_high - g_ads_calibration.raw_low);
    }
    return 50.0f + ADS_ReadVoltage() * 995.0f;//理论格式 距离=50+995*电压 电压线性变化
}
