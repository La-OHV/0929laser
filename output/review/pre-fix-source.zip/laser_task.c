//
// Created by 23906 on 2026/9/29.
//

#include "laser_task.h"
//
// Created by 23906 on 2026/9/24.
//

#include "../DRV+SEV/ads8688.h"
#include "FreeRTOS.h"
#include "task.h"
#include <math.h>

volatile float g_distance_mm = NAN;
volatile uint32_t g_laser_task_count = 0U;
volatile uint32_t g_laser_sample_count = 0U;
volatile uint16_t g_ads_channel_raw[8] = {0U};
volatile uint8_t g_ads_init_ok = 0U;
static uint8_t sample_count = 0U;//采样计数器 任务跑10ms周期 ads每100ms才读一次
//初始化
void app_init(void)
{
    sample_count = 0U;//计数器归零
    g_laser_task_count = 0U;
    g_laser_sample_count = 0U;
    for (uint8_t channel = 0U; channel < 8U; ++channel)
    {
        g_ads_channel_raw[channel] = 0U;
    }
    g_distance_mm = NAN;//清掉旧值
    g_ads_init_ok = ADS_Init();
}
//10ms被调用一次
void app_task_10ms(void)
{
    ++g_laser_task_count; //正常运行时约每秒增加100，判断任务是否持续执行
    if (++sample_count >= 10U)
    {
        sample_count = 0U;
        for (uint8_t channel = 0U; channel < 8U; ++channel)
        {
            g_ads_channel_raw[channel] = ADS_ReadChannelRaw(channel);
        }
        g_distance_mm = (g_ads_init_ok && (g_ads_channel_valid_mask & (1U << 1)))
                      ? 50.0f + (float)g_ads_channel_raw[1] * 995.0f * 10.24f / 65536.0f
                      : NAN;
        ++g_laser_sample_count; //采样函数返回后增加，正常约每秒10次；不代表通信成功
    }
}

void laser_task(void *argument)
{
    (void)argument;
    app_init();
    TickType_t last_wake = xTaskGetTickCount();//记录上一次唤醒的时刻

    for (;;)
    {
        vTaskDelayUntil(&last_wake, pdMS_TO_TICKS(10U));//10ms 函数执行的时间会被自动吸收
        app_task_10ms();
    }
}
